# Real-time Language Translator 🗣️🌐

A Python desktop application using Tkinter, Google Translate API, and gTTS to translate text between languages and speak it aloud.

## Features
- Translate between 15+ languages
- Text-to-speech output
- Save and show recent translation history
- Audio playback & download
- Scrollable and user-friendly interface

## Requirements
- Python 3.x
- See `requirements.txt`

## How to Run
```bash
pip install -r requirements.txt
python translator_app.py
```